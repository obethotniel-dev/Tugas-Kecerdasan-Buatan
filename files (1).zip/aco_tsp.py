"""
Traveling Salesman Problem - Ant Colony Optimization
======================================================
Graph  : Gambar 1 (nodes: #, A, B, C, D, E, F, G, H)
Constraint:
  - Start  = H
  - End    = D
  - WAJIB melewati titik # (HASH)
  - Kunjungi SEMUA node tepat 1 kali

Author : [Your Name]
"""

import random
import copy

# ============================================================
# DEFINISI GRAPH (dari Gambar 1)
# ============================================================
NODES = ['HASH', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H']
# '#' direpresentasikan sebagai 'HASH' di kode

EDGES = {
    ('HASH', 'A'): 3,
    ('HASH', 'C'): 2,
    ('HASH', 'G'): 5,
    ('A',    'C'): 6,
    ('A',    'B'): 9,
    ('C',    'D'): 4,
    ('C',    'F'): 4,
    ('F',    'E'): 2,
    ('E',    'G'): 1,
    ('E',    'H'): 1,
    ('E',    'D'): 7,
    ('G',    'H'): 3,
    ('B',    'H'): 8,
    ('B',    'D'): 9,
}

N   = len(NODES)
IDX = {node: i for i, node in enumerate(NODES)}
INF = float('inf')

# Build adjacency matrix
DIST = [[INF] * N for _ in range(N)]
for i in range(N):
    DIST[i][i] = 0
for (u, v), w in EDGES.items():
    i, j = IDX[u], IDX[v]
    DIST[i][j] = w
    DIST[j][i] = w

# Build adjacency list
ADJ = {i: [] for i in range(N)}
for (u, v), w in EDGES.items():
    i, j = IDX[u], IDX[v]
    ADJ[i].append(j)
    ADJ[j].append(i)

# ============================================================
# ACO PARAMETERS
# ============================================================
NUM_ANTS       = 30
NUM_ITERATIONS = 200
ALPHA          = 1.0    # bobot feromon
BETA           = 3.0    # bobot heuristik (1/jarak)
RHO            = 0.3    # laju evaporasi feromon
Q              = 100.0  # konstanta deposit feromon
TAU_INIT       = 1.0    # feromon awal

# ============================================================
# HELPER
# ============================================================
def name(i):
    return NODES[i].replace('HASH', '#')

def path_cost(path):
    total = 0
    for k in range(len(path) - 1):
        d = DIST[path[k]][path[k+1]]
        if d == INF:
            return INF
        total += d
    return total

# ============================================================
# ACO CORE
# ============================================================
def init_pheromone():
    return [[TAU_INIT] * N for _ in range(N)]

def select_next(current, visited, pheromone):
    """Pilih node berikutnya secara probabilistik (roulette wheel)."""
    scores = []
    candidates = []
    for j in ADJ[current]:
        if j not in visited:
            tau = pheromone[current][j] ** ALPHA
            eta = (1.0 / DIST[current][j]) ** BETA
            scores.append(tau * eta)
            candidates.append(j)
    if not candidates:
        return None
    total = sum(scores)
    if total == 0:
        return random.choice(candidates)
    r = random.random() * total
    cum = 0.0
    for s, c in zip(scores, candidates):
        cum += s
        if r <= cum:
            return c
    return candidates[-1]

def construct_path(pheromone, start, end, must):
    """
    Bangun Hamiltonian path: start -> ... -> must -> ... -> end
    menggunakan probabilistic ACO selection.
    Strategi:
      1. Dari start, kunjungi semua node kecuali end,
         pastikan 'must' dilewati sebelum end.
      2. Akhiri di end.
    """
    visited = {start}
    path    = [start]
    current = start

    # Semua node yang harus dikunjungi (selain start & end)
    middle_nodes = [i for i in range(N) if i != start and i != end]
    must_visited = (must == start)  # True jika start == must

    # Kunjungi semua middle nodes
    remaining = set(middle_nodes)
    max_steps = N * N * 2
    steps = 0

    while remaining:
        steps += 1
        if steps > max_steps:
            return None  # gagal, coba lagi

        nxt = select_next(current, visited, pheromone)
        if nxt is None:
            return None

        # Jangan ke 'end' sebelum semua node dikunjungi
        if nxt == end:
            continue

        visited.add(nxt)
        path.append(nxt)
        remaining.discard(nxt)
        if nxt == must:
            must_visited = True
        current = nxt

    # Pastikan 'must' sudah dikunjungi
    if not must_visited:
        return None

    # Pergi ke end
    if DIST[current][end] == INF:
        return None
    path.append(end)

    # Validasi akhir
    if len(path) != N:
        return None
    if set(path) != set(range(N)):
        return None

    return path

def evaporate_and_deposit(pheromone, paths, costs):
    # Evaporasi
    for i in range(N):
        for j in range(N):
            pheromone[i][j] = max(1e-6, pheromone[i][j] * (1 - RHO))

    # Deposit feromon
    for path, cost in zip(paths, costs):
        if path is None or cost == INF:
            continue
        deposit = Q / cost
        for k in range(len(path) - 1):
            i, j = path[k], path[k+1]
            pheromone[i][j] += deposit
            pheromone[j][i] += deposit

# ============================================================
# MAIN
# ============================================================
def run_aco(seed=42):
    random.seed(seed)

    START = IDX['H']
    END   = IDX['D']
    MUST  = IDX['HASH']

    print("=" * 62)
    print("  TSP - ANT COLONY OPTIMIZATION")
    print("=" * 62)
    print(f"  Nodes  : {[name(i) for i in range(N)]}")
    print(f"  Start  : H  |  End : D  |  Wajib lewat : #")
    print(f"  Ants   : {NUM_ANTS}  |  Iterations : {NUM_ITERATIONS}")
    print(f"  alpha={ALPHA}, beta={BETA}, rho={RHO}, Q={Q}")
    print()
    print("  Edges (u -- v : bobot):")
    for (u, v), w in EDGES.items():
        print(f"    {u.replace('HASH','#'):>4} -- {v:<4} : {w}")
    print()

    pheromone   = init_pheromone()
    best_path   = None
    best_cost   = INF
    history     = []

    print(f"  {'Iter':>5} | {'Jarak Terbaik':>14} | Rute")
    print("  " + "-" * 58)

    for it in range(1, NUM_ITERATIONS + 1):
        it_paths = []
        it_costs = []

        for _ in range(NUM_ANTS):
            path = construct_path(pheromone, START, END, MUST)
            cost = path_cost(path) if path else INF
            it_paths.append(path)
            it_costs.append(cost)
            if cost < best_cost:
                best_cost = cost
                best_path = copy.copy(path)

        evaporate_and_deposit(pheromone, it_paths, it_costs)
        history.append(best_cost)

        if it % 20 == 0 or it == 1:
            route = " -> ".join(name(i) for i in best_path) if best_path else "belum ditemukan"
            cost_str = f"{best_cost:.1f}" if best_cost != INF else "INF"
            print(f"  {it:>5} | {cost_str:>14} | {route}")

    # ---- HASIL AKHIR ----
    print()
    print("=" * 62)
    print("  HASIL AKHIR")
    print("=" * 62)

    if best_path:
        names = [name(i) for i in best_path]
        print(f"\n  Rute terbaik : {' -> '.join(names)}")
        print(f"  Total jarak  : {best_cost}")
        print()
        print("  Detail perjalanan:")
        for k in range(len(best_path) - 1):
            u, v = best_path[k], best_path[k+1]
            d = DIST[u][v]
            print(f"    {name(u):>4}  ->  {name(v):<4}   jarak = {d}")
        print(f"    {'':>4}      {'TOTAL':<4}   jarak = {best_cost}")

        print()
        print("  Verifikasi Constraint:")
        print(f"    Start = H        : {'PASS ✓' if names[0]  == 'H' else 'FAIL ✗'}")
        print(f"    End   = D        : {'PASS ✓' if names[-1] == 'D' else 'FAIL ✗'}")
        print(f"    Lewati #         : {'PASS ✓' if '#' in names else 'FAIL ✗'}")
        all_visited = len(set(names)) == N
        print(f"    Semua node (x1)  : {'PASS ✓' if all_visited else 'FAIL ✗'}")
    else:
        print("\n  Tidak ditemukan solusi valid.")

    return best_path, best_cost

if __name__ == "__main__":
    run_aco()
