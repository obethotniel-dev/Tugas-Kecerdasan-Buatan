# TSP - Ant Colony Optimization

Menyelesaikan **Traveling Salesman Problem (TSP)** pada graph Gambar 1 menggunakan algoritma **Ant Colony Optimization (ACO)**.

## Constraint
| Parameter | Nilai |
|-----------|-------|
| Start node | **H** |
| End node | **D** |
| Wajib melewati | **#** |
| Kunjungi semua node | Ya (tepat 1x) |

## Graph (Gambar 1)
```
Nodes : #, A, B, C, D, E, F, G, H

Edges :
  # -- A : 3      C -- D : 4
  # -- C : 2      C -- F : 4
  # -- G : 5      F -- E : 2
  A -- C : 6      E -- G : 1
  A -- B : 9      E -- H : 1
  B -- H : 8      E -- D : 7
  B -- D : 9      G -- H : 3
```

## Hasil
```
Rute terbaik : H -> G -> E -> F -> C -> # -> A -> B -> D
Total jarak  : 33

Detail:
  H -> G  = 3
  G -> E  = 1
  E -> F  = 2
  F -> C  = 4
  C -> #  = 2
  # -> A  = 3
  A -> B  = 9
  B -> D  = 9
        TOTAL = 33
```

## Cara Menjalankan
```bash
python3 aco_tsp.py
```
> Tidak memerlukan library eksternal. Cukup Python 3.x standar.

## Parameter ACO
| Parameter | Nilai | Keterangan |
|-----------|-------|------------|
| Jumlah semut | 30 | Banyak agen pencari |
| Iterasi | 200 | Jumlah siklus |
| Alpha (α) | 1.0 | Bobot feromon |
| Beta (β) | 3.0 | Bobot heuristik (1/jarak) |
| Rho (ρ) | 0.3 | Laju evaporasi feromon |
| Q | 100 | Konstanta deposit feromon |

## Referensi
- Raghavendra BV (2015). *Solving Traveling Salesmen Problem using Ant Colony Optimization Algorithm*. J Appl Computat Math 4:260.
- Dorigo M, Gambardella LM (1997). *Ant Colony System*. IEEE Transactions on Evolutionary Computation.
